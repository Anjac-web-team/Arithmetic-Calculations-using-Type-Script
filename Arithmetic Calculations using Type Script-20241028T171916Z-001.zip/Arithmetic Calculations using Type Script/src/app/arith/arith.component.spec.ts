import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArithComponent } from './arith.component';

describe('ArithComponent', () => {
  let component: ArithComponent;
  let fixture: ComponentFixture<ArithComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ArithComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ArithComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
