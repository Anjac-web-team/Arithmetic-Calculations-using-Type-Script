import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; 

@Component({
  selector: 'app-arith',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './arith.component.html',
  styleUrl: './arith.component.css'
})
export class ArithComponent {
  data:any={};
  add(){
    this.data.result=`The addition of ${this.data?.firstNumber} and ${this.data?.secondNumber} is : ${this.data?.firstNumber+this.data?.secondNumber}`;
  };
  sub(){
    this.data.result=`The Subtraction of ${this.data?.firstNumber} and ${this.data?.secondNumber} is : ${this.data?.firstNumber-this.data?.secondNumber}`;
  }
  mul(){
    this.data.result=`The Multiplication of ${this.data?.firstNumber} and ${this.data?.secondNumber} is : ${this.data?.firstNumber*this.data?.secondNumber}`;
  }
  div(){
    this.data.result=`The Division of ${this.data?.firstNumber} and ${this.data?.secondNumber} is : ${Math.floor(this.data?.firstNumber/this.data?.secondNumber)}`;
  }
  modulo(){
    this.data.result=`The Modulo division of ${this.data?.firstNumber} and ${this.data?.secondNumber} is : ${this.data?.firstNumber%this.data?.secondNumber}`;
  }
  clear(){
    this.data={}
  }
}
